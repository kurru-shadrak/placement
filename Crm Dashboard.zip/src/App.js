
import './App.css';
import Router from './components/routes.jsx';
import YourCourses from './components/yourcourses/YourCourses';


function App() {
  return (
    <div className="App">
       <Router/>   
       
      
    </div>
  );
}

export default App;
