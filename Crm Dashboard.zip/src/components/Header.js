import React from 'react'
 import person from '../assets/kurru shadrak.jpg'
import { NotificationsNone } from '@mui/icons-material'
import { useTime } from 'react-timer-hook';

function Header() {
  const date =  new Date().toLocaleTimeString();
  
  var greetings = "";
  
    const hour = new Date().getHours();
    
    if(hour>1 && hour<12){
        greetings = "Good Morning";
    } 
    else if(hour>=12 && hour<18)
     {
        greetings = "Good Afternoon";
    } 
    else if(hour>18 && hour<=20) 
    {
        greetings = "Good Evening";
    } 
    else if(hour>20)
    {
        greetings = "Good Night";
    }
    
    var ampm = (hour >= 12) ? "PM" : "AM";
  const {
    
    hours,
    minutes,
    seconds,
  
  }=useTime({format:'12-hours'})
  return (
    <nav className="w-full h-[50px]  rounded-xl mb-3 flex items-center justify-between" style={{backgroundColor:"#0054a6"}}>
      <div className='flex justify-start items-center text-white text-xl'>
      {/* <div className="p-1 mr-2 ">
        <a className="font-semibold cursor-pointer  "></a>
      </div>
      <div className="p-1 mr-2 ">
        <a className="font-semibold cursor-pointer  "><span></span><span>{hours} {''}</span><span>  : {''}</span><span>  {minutes} {''}</span><span> : {''}</span><span>{seconds} {''} {''}</span><span >{ampm}</span></a>
      </div>*/}
      </div> 
     <div className='justify-end flex gap-3  items-center text-white'>
      <div className="p-1 mr-2 ">
        <a className="font-semibold cursor-pointer  "><NotificationsNone className='text-xl' style={{fontSize:24}}/></a>
      </div>
      <div className="p-1 mr-2 dropdown">
        <button className="font-semibold cursor-pointer text-xl ">Kurru Shadrak</button>
    
  

      </div>
      <div className=" mr-2 dropdown">
        <img src={person} alt="" className="persologo cursor-pointer rounded-full bg-white " width="40px" height="40px"/>
        <div className="dropdown-content text-black flex flex-col z-0">
    <div >Profile</div>
    <div >Setting</div>
    <div>LogOut</div>
  </div>
      </div>
      </div>
    </nav>
  )
}

export default Header