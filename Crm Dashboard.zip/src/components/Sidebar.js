import React from 'react'
import logo from '../assets/blue-logo.png'


import { Dashboard, HelpCenter, History, Person, PowerSettingsNew, School, Settings, WorkspacePremium } from '@mui/icons-material'
import { BrowserRouter, Link, Navigate, Route, Routes, useNavigate } from 'react-router-dom'

function Sidebar() {
  const navigate=useNavigate()
  return (
    <div className="h-[700px] shadow-md  rounded-2xl p-2 justify-start  text-black" style={{backgroundColor:"white"}}>
      {/* <h4 className="text-2xl font-medium mb-5">Dashboard</h4>
       */}
       <div className="rounded-2xl p-1  cursor-pointer " ><img src={logo} alt=""  width='180' height='100' className='bg-white rounded-xl ml-9 ' onClick={()=>navigate('app')}/></div>
       <hr className="hrline mt-2" />
       <div className=" text-xl text-black-300 text-start ">
       
      <div className="p-1 mt-5 items-center flex justify-start	hover:bg-[#0054a6] hover:text-white hover:rounded-xl">
        <Dashboard className='mr-1 ds'/><span className="font-semibold cursor-pointer  "><button  onClick={()=>navigate('app')}>Dashboard </button></span>
      </div>
      <div className="p-1 mt-3 items-center  flex justify-start	 	hover:bg-[#0054a6] hover:text-white hover:rounded-xl">
        <School className='mr-1'/><span className="font-semibold cursor-pointer ">  <button onClick={()=>navigate('mycourses')}>My Courses </button></span>
      </div>
      <div className="p-1 mt-3 items-center flex justify-start		hover:bg-[#0054a6] hover:text-white hover:rounded-xl">
       <History className='mr-1'/> <span className="font-semibold cursor-pointer  "><button onClick={()=>navigate('orderhistory')}>Order History</button></span>
      </div>
      <div className="p-1 mt-3 items-center flex justify-start		hover:bg-[#0054a6] hover:text-white hover:rounded-xl	 ">
       <Person className='mr-1'/> <span className="font-semibold cursor-pointer  "><button onClick={()=>navigate('myprofile')}>My Profile</button></span>
      </div>
      
      <div className="p-1  mt-3 items-center  flex justify-start		 	hover:bg-[#0054a6] hover:text-white hover:rounded-xl">
      <WorkspacePremium className='mr-1'/>  <span className="font-semibold cursor-pointer "><button onClick={()=>navigate('mycertificates')}>My Certificates</button></span>
      </div>
      
      <hr className='font-bold' style={{marginTop:190}}/>
      <div className="p-1 mt-3 items-center flex  justify-start		">
        <Settings className='mr-1'/><span className=" cursor-pointer hover:underline "><button onClick={()=>navigate('setting')} className='hover:underline'>Settings</button></span>
      </div>
      <div className="p-1 mt-3 items-center flex  justify-start		 ">
        <HelpCenter className='mr-1'/><span className=" cursor-pointer hover:underline "><button onClick={()=>navigate('setting')} className='hover:underline'>Help Center</button></span>
      </div>
      <div className="p-1 mt-3  items-center  flex justify-start	 ">
        <PowerSettingsNew className='mr-1'/><a className=" cursor-pointer hover:underline ">Logout</a>
      </div>
      
      </div>
    
    </div>
  )
}

export default Sidebar