import React from 'react'
import './CoursesList.css'
import { useNavigate } from 'react-router-dom';
import StarRatings from 'react-star-ratings';

// import StarRatings from "react-star-ratings/build/star-ratings";
const courseList = [
    {
      title: "The Complete Core Java From Zero to Hero in java",
      professor: "Madam Begum",
      description:
        "Learn Core Java like a Professional Start from the basics and go all the way to creating your own applications and games",
      duration: "45h",
      rating: 4.5,
      raters: 4534,
      url:"https://www.tecwallet.com/ImageUploaderNew/uploads/18_4_2013_16_03_190_core_java_6884011458.jpg"
    },
     {
       title: "The Complete Backed Java From Zero to Hero in Java ",
       professor: "Shiva",
       description:
         "Learn html like a Professional Start from the basics and go all the way to creating your own applications and mobile application ",
       duration: "15h",
       rating: 5,
       raters: 4534,
       url:"https://th.bing.com/th/id/OIP.wmVr1W0nuF_M_OswcpjyjgHaEc?w=298&h=180&c=7&r=0&o=5&dpr=1.3&pid=1.7",

     },
  //   {
  //     title: "The Complete CSS From Zero to Hero in css",
  //     professor: "Chandra Sekhar",
  //     description:
  //       "Learn CSS like a Professional Start from the basics and go all the way to creating your own applications and mobile application ",
  //     duration: "25h",
  //     rating: 5,
  //     raters: 4534,
  //     url:"https://www.vectorlogo.zone/logos/w3_css/w3_css-ar21.png",
    
  //   },
  //  {
  //      title: "The Complete JavaScript From Zero to Hero ",
  //       professor: "Chandra Sekhar",
  //       description:
  //         "Learn JavaScipt like a Professional Start from the basics and go all the way to creating your own Dynamic web applications and games",
  //       duration: "45h",
  //       rating: 4.5,
  //       raters: 4534,
  //        url:"https://ictacademy.com.ng/wp-content/uploads/2020/02/92.-JavaScript-logo.png",
        
  //      },
       {
        title: "The Complete ReactJS From Zero to Hero ",
         professor: "Chandra Sekhar",
         description:
           "Learn JavaScipt like a Professional Start from the basics and go all the way to creating your own Dynamic web applications and games",
         duration: "45h",
         rating: 4.5,
         raters: 4534,
          url:"https://th.bing.com/th/id/OIP.E13JkGWNBoKw9e1-WatrCgHaD_?pid=ImgDet&rs=1",
         
        },
        {
          title: "The Complete Python From Zero to Hero ",
           professor: "Chandra Sekhar",
           description:
             "Learn JavaScipt like a Professional Start from the basics and go all the way to creating your own Dynamic web applications and games",
           duration: "45h",
           rating: 4.5,
           raters: 4534,
            url:"https://1.bp.blogspot.com/-5iaqcKxhxgc/X1uavDbEfxI/AAAAAAAALWw/OO0wkFuXc3I0fBJS9Q3GgOKlbBSdFfHBQCLcBGAsYHQ/w1200-h630-p-k-no-nu/python-logo.png",
           
          },
  ];

function CoursesList() {
      const navigate = useNavigate();
  return (
    <div className="h-full shadow-md bg-white rounded-xl p-2  overflow-scroll">
      <h4 className="text-2xl font-medium mb-5">Your Courses</h4>

      {courseList.map((course, ind) => {
        return (
          <div key={ind} className="grid grid-cols-1 cursor-pointer   " >
            <div className="item-box m-2  ">
              <div className="w-full border p-2 rounded-lg hover:shadow ">
                <div className="flex p-2 ">
                  <div>
                   
                    <img src={course.url}
                    
                      alt='' style={{width:300,height:125,borderRadius:10}}
                   />
                  </div>
                  <div className='grid grid-cols-1 rounded-lg 'style={{textAlign:"left",marginLeft:20}}>
                    <p className="text-sm font-semibold ">{course.title}</p>
                    <p className="text-sm font-semibold ">{course.professor}</p>
                    <span className="text-sm ">{course.description}</span>
                    <div>
                      <StarRatings
                        starDimension="20px"
                        starSpacing="1px"
                        rating={course.rating}
                        starRatedColor="#000"
                        // changeRating={this.changeRating}
                        numberOfStars={5}
                        name="rating"
                      />
                      {course.raters > 0 && (
                        <span className="text-sm ml-1">
                          ({new Number(course.raters).toLocaleString()})
                        </span>
                      )}
                    </div>
                    <div>
                      <label className="text-gray-700 font-medium text-sm">
                        Duration
                      </label>
                      <span className="ml-4 font-medium bg-slate-100 rounded-lg text-xs p-[3px]">
                        {course.duration}
                      </span>
                      
                      <button
                        onClick={() => navigate("course-details/1234")} 
                        type="button"
                        className="text-white float-right   p-2  focus:outline-none focus:ring-4 focus:ring-gray-300 font-medium  rounded-md text-sm px-2 ml-2 hover:bg-blue-600 bg-[#0054a6]"
                        >
                        Start Learning
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        );
      })}
    </div>
  )
}

export default CoursesList