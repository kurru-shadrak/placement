import React from 'react'
import { useNavigate } from 'react-router-dom';
import './Signinup.css'
import logo from '../../assets/blue-logo.png'


function SignUp() {
     const navigate=useNavigate();
   
  return (
    <div className='signin text-center '>
      <div className="signin-wraper">
        <div className="logo flex items-center justify-center">
 <img src={logo}  alt='logo'/>
</div>
        <h1 className='text-2xl font-serif'>Create Account</h1>
        <p className='font-serif'>Fill in the fields below to sign up for an account.
</p>
<div className=' rounded-xl'>
<form className='mt-5'>
<div className=' name text-center mb-3'>

<input type="text" placeholder='Name ' />

</div>
<div className=' email text-center mb-3'>

<input type="text" placeholder='Email address'/>

</div>
<div className='password text-center mb-3'>

<input type="password" placeholder='Password' />

</div>
<div className='password text-center mb-3'>

<input type="password" placeholder='Confirmed Password' />

</div>
<div className='text-center mb-3 float-left'>

<input type="checkbox" value="I accept the terms and conditions."  className='cursor-pointer '/> I accept the terms and conditions

</div>
<div className='text-center mb-3'>

<button className=' bg-blue-700 p-2 px-20 text-white rounded-xl text-2xl hover:bg-blue-600' >Sign Up</button>

</div>
<div className='text-center mb-3'>

<span>Already have an account? <button onClick={()=>navigate('/')} style={{border:"none",color:"blue"}}>Sign in</button></span>

</div>
</form>
</div>
</div>
    </div>
  )
}

export default SignUp