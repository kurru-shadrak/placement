import React, { useRef } from 'react'
import { useNavigate } from 'react-router-dom'
import './Signinup.css'
import logo from '../../assets/blue-logo.png'

function Signin() {
  const emailRef=useRef();
  const passwordRef=useRef();
  
  const submitForm =(e)=>{
    e.preventDefault();
    console.log({email:emailRef.current.value,passwod:passwordRef.current.value})

  }
     const navigate=useNavigate();
   
  return (
    <div className='signin text-center h-full'>
      <div className="signin-wraper">
        <div className="logo  flex items-center justify-center">
 <img src={logo}  alt='logo' className=' '/>
</div>
<div className='mt-16 h-76 rounded-xl'>
<form className='p-4 ' onClick={submitForm}>
<fieldset>

    
        
<div className=' email mb-3'>
 <input type="email" placeholder='Email '   height="100" width="100" ref={emailRef} /> 
</div>
<div className=' password mt-8'>

<input type="password" placeholder='Password'  height="100" width="100" ref={passwordRef}/>

</div>
{/* <div className='text-center mb-3'>

<input type="checkbox" value="I accept the terms and conditions." style={{marginLeft:-110}} onChange={(e)=>setCheckbox(e.target.value)}/>  <span >{''}I accept the terms and conditions</span>

</div> */}
<div className='text-center mt-4'>

<button type='submit' className='bg-blue-700 p-2 px-20 text-white rounded-xl text-2xl hover:bg-blue-600' onClick={()=>navigate('/home')} >Sign in</button>

</div>
<div className='text-center mt-4'>

<p>Don’t have an account, yet? <button onClick={()=>navigate('/signup')}  style={{border:"none",color:"blue"}} >Sign up Here</button></p>

</div>
</fieldset>
</form>
</div>
</div>
</div>
  )
}

export default Signin